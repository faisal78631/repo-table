//
//  ProductsCell.swift
//  table-CollectionView
//
//  Created by Faisal Liaquat on 10/10/2020.
//

import UIKit

class ProductsCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var title1: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var price: UILabel!

    func UpdateViews(imgView: String, title: String , name: String, price: String)
    {
        self.imgView.image = UIImage(named: imgView)
        self.title1.text = title
        self.name.text = name
        self.price.text = price
    }
    
}
