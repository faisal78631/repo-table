//
//  service.swift
//  table-CollectionView
//
//  Created by Faisal Liaquat on 10/10/2020.
//

import Foundation

class DataService{
    static let instance = DataService()
    
    private let categories = [
        Category(title: "Category 1", imageName: "shirts.png"),
        Category(title: "Category 2", imageName: "hoodies.png"),
        Category(title: "Category 3", imageName: "hats.png"),
        Category(title: "Category 4", imageName: "digital.png")
    ]
    
    func getCategories() -> [Category]{
        return categories
    }
    
    private let hats = [
        Product(title: "product description here", price: "$18", imageName: "hat01.png"),
        Product(title: "product description here", price: "$18", imageName: "hat02.png"),
        Product(title: "product description here", price: "$18", imageName: "hat03.png"),
        Product(title: "product description here", price: "$18", imageName: "hat04.png"),
    ]
    
    private let hoodies = [
        Product(title: "product description here", price: "$18", imageName: "hoodie01.png"),
        Product(title: "product description here", price: "$18", imageName: "hoodie02.png"),
        Product(title: "product description here", price: "$18", imageName: "hoodie03.png"),
        Product(title: "product description here", price: "$18", imageName: "hoodie04.png"),
    ]

    private let shirts = [
        Product(title: "product description here", price: "$18", imageName: "shirt01.png"),
        Product(title: "product description here", price: "$18", imageName: "shirt02.png"),
        Product(title: "product description here", price: "$18", imageName: "shirt03.png"),
        Product(title: "product description here", price: "$18", imageName: "shirt04.png"),
    ]
    
    private let digital = [Product]()

    func getProducts(forCategoryTitle title:String) -> [Product] {
        switch title {
        case "Category 1":
            return getShirts()
        case "Category 2":
            return getHat()
        case "Category 3":
            return gethoodies()
        case "Category 4":
            return getDigital()
        default:
            return getShirts()
        }
    }

    func getHat() -> [Product]
    {
        return hats
    }
    
    func gethoodies() -> [Product]
    {
        return hoodies

    }
    
    func getShirts() -> [Product]
    {
        return shirts
    }
    
    func getDigital() -> [Product]
    {
        return digital
    }


}
