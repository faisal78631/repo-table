//
//  modelCateg.swift
//  table-CollectionView
//
//  Created by Faisal Liaquat on 10/10/2020.
//

import Foundation

struct Category{
    private(set) public var title: String
    private(set) public var imageName: String
    
    init(title: String, imageName: String ) {
        self.title = title
        self.imageName = imageName
    }
    
    
}
