package com.example.tbl_tableview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class details123 extends AppCompatActivity {

    private TextView description;
    private Bundle extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details123);

        description = (TextView) findViewById(R.id.dDescription);

        extras = getIntent().getExtras();

        if(extras != null)
        {
            description.setText(extras.getString("description"));
        }
    }
}
