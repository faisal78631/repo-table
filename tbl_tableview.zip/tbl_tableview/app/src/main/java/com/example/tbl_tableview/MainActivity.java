package com.example.tbl_tableview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import adapter.myadapter;
import model.ListItem;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private List<ListItem> ListItems1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recyclersView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ListItems1 = new ArrayList<>();

        ListItem item1 = new ListItem("Movie1","its crazy and really its not bad tooooooo");
        ListItem item2 = new ListItem("Movie2","its crazy and really its not bad toooooooooooooooooo");

//        for (int i=0 ; i< 10 ;i++)
//        {
//            ListItem item = new ListItem(
//                    "Item " + (i+1),
//                    "Description"
//            );
//            ListItems1.add(item);
//        }

        ListItems1.add(item1);
        ListItems1.add(item2);

        adapter = new myadapter(this,ListItems1);
        recyclerView.setAdapter(adapter);
    }
}
