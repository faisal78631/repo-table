package adapter;

import android.content.Context;
import android.content.Intent;
import android.telecom.Call;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tbl_tableview.R;
import com.example.tbl_tableview.details123;

import org.w3c.dom.Text;

import java.util.List;

import model.ListItem;

public class myadapter extends RecyclerView.Adapter<myadapter.ViewHolder> {

    private Context context;
    private List<ListItem> listItems;
    public myadapter(Context context, List listItem)
    {
        this.context = context;
        this.listItems = listItem;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myadapter.ViewHolder holder, int position) {
        ListItem item = listItems.get(position);

        holder.name.setText(item.getName());
        holder.description.setText(item.getDescription());


    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView name;
        public  TextView description;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            itemView.setOnClickListener(this);
            name = (TextView) itemView.findViewById(R.id.title);
            description = (TextView) itemView.findViewById(R.id.description);
        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            ListItem item = listItems.get(position);

            Intent intent = new Intent(context, details123.class);
            intent.putExtra("name",item.getName());
            intent.putExtra("description", item.getDescription());

            context.startActivity(intent);
            Toast.makeText(context, item.getName() + item.getDescription(), Toast.LENGTH_LONG).show();
        }
    }
}
